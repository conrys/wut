/* Хованки — Firebase Realtime Database transport (for your own app, e.g. 41 Games).
   Not used inside the Claude artifact. Untested here: Firebase is not reachable from the build sandbox.

   Use:
     <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
     <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-database-compat.js"></script>
     <script>firebase.initializeApp({ ...your config... });</script>
     <script src="net-firebase.js"></script>          <!-- before game.js -->
     <script src="three.min.js"></script><script src="world.js"></script><script src="game.js"></script>

   Data layout: /hns/{code}/{peerId} = { p: {...presence}, t: serverTimestamp }
   Suggested rules (tighten to your auth model):
     { "rules": { "hns": { "$code": { ".read": true, "$peer": { ".write": true } } } } }

   The game only needs: ready() -> bool, join(code) -> { presence(patch), peers(), leave() }.
   peers() returns [{ id, isMe, presence, updatedAt }] and must be a cheap synchronous getter. */
(function(){
  if(!window.firebase||!firebase.database)return;
  const db=firebase.database();
  window.HNS_TRANSPORT={
    async ready(){return true},
    async join(code){
      const id=db.ref().push().key,roomRef=db.ref('ph/'+code),meRef=roomRef.child(id);
      let mine={},dirty=false,last=0,list=[{id,isMe:true,presence:{},updatedAt:Date.now()}];
      const seen=new Map();
      meRef.onDisconnect().remove();
      roomRef.on('value',snap=>{
        const v=snap.val()||{},now=Date.now(),next=[];
        for(const pid in v){
          if(pid===id)continue;
          const pres=(v[pid]&&v[pid].p)||{},json=JSON.stringify(pres),old=seen.get(pid);
          const updatedAt=old&&old.json===json?old.updatedAt:now;seen.set(pid,{json,updatedAt});
          next.push({id:pid,isMe:false,presence:Object.freeze(pres),updatedAt});
        }
        for(const pid of[...seen.keys()])if(!(pid in v))seen.delete(pid);
        list=[{id,isMe:true,presence:Object.freeze({...mine}),updatedAt:now}].concat(next);
      });
      // positions change every frame: write at most ~15 times a second
      const pump=setInterval(()=>{if(!dirty)return;const t=Date.now();if(t-last<66)return;last=t;dirty=false;
        meRef.set({p:mine,t:firebase.database.ServerValue.TIMESTAMP}).catch(()=>{})},33);
      return{
        presence(patch){for(const k in patch){if(patch[k]===null)delete mine[k];else mine[k]=patch[k]}dirty=true;
          list=[{id,isMe:true,presence:Object.freeze({...mine}),updatedAt:Date.now()}].concat(list.filter(p=>!p.isMe));return Promise.resolve()},
        peers(){return list},
        leave(){clearInterval(pump);roomRef.off();return meRef.remove().catch(()=>{})},
      };
    },
  };
})();
