# Як у рекламі

12 справжніх ігор з «фейкових» мобільних реклам. Чистий HTML + JS, без збірки, працюють офлайн.

Відкрий `index.html` (або `npx serve .`) — це меню з усіма іграми. У кожній грі стрілка зліва вгорі повертає в меню.

## Ігри

| Папка | Гра | Технології |
|---|---|---|
| `games/natovp-2d` | Натовп ×3, 2D-раннер з воротами-множниками | Canvas 2D |
| `games/natovp-3d` | Натовп ×3, 3D: лицарі в строю, вежа-бос | three.js + `engine.js` |
| `games/dira-2d` | Діра-ненажера, 2D | Canvas 2D |
| `games/dira-3d` | Діра-ненажера, 3D з трафаретною діркою | three.js |
| `games/shpylka` | Витягни шпильку: лава, вода, золото, монстр | Canvas 2D + `pinsim.js` (фізика частинок) |
| `games/pesyk` | Врятуй песика: малюєш лінію від бджіл | Canvas 2D + planck.js (Box2D) |
| `games/kolby` | Сортування рідин у колбах | Canvas 2D + `sortcore.js` (генератор + розв'язувач) |
| `games/vezha-spiral` | Спіральна вежа (Helix Jump) | three.js + `engine.js` |
| `games/parkovka` | Тісна парковка (Parking Jam) | Canvas 2D + `parkcore.js` |
| `games/vezha-blokiv` | Вежа з блоків (Stack) | three.js |
| `games/khovanky` | Хованки: 2 карти, темрява, присідання, мультиплеєр | three.js + `world.js` + `game.js` |
| `games/perevtilennia` | Перевтілення (Prop Hunt), мультиплеєр | three.js + `world.js` + `game.js` |

Бібліотеки лежать у `vendor/`: three.js r128 і planck.js 1.0.6 (обидві MIT).

## Збереження

Прогрес і рекорди пишуться в `localStorage` під ключами з префіксом гри (`n3d_level`, `pin_level`, `sort_level`, `park_level`, `helix_level`, `stack_best`, `hns_level`, `ph_level`, `ph_best` тощо), тож ігри не заважають одна одній.

## Мультиплеєр (Хованки, Перевтілення)

Мережа підключається через `window.HNS_TRANSPORT`. В артефакті Claude працює вбудована кімната; тут потрібен свій транспорт.

У папці кожної з двох ігор є `net-firebase.js`. Щоб увімкнути Firebase Realtime Database:

```html
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-database-compat.js"></script>
<script>firebase.initializeApp({ /* твій конфіг */ });</script>
<script src="net-firebase.js"></script>   <!-- перед game.js -->
```

Шляхи в базі: `hns/{код}` для Хованок, `ph/{код}` для Перевтілення. Правила й деталі — в коментарі на початку `net-firebase.js`. Адаптер не перевірявся в живому Firebase; логіка мультиплеєра перевірена двома вкладками через локальний транспорт.

## Android (Capacitor)

```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Як у рекламі" ua.yakureklami.games --web-dir .
npx cap add android
npx cap open android
```

Краще перенести вміст архіву в `www/` і вказати `--web-dir www`. Без інтернету не підвантажаться лише шрифти Google Fonts (підставиться системний шрифт) і Firebase.
